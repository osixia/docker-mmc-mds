<?php

$module_audit_codes = array(
    'PPOLICY_MOD_USER_ATTR' => _T("Change ppolicy attribute", "ppolicy"),
    'PPOLICY_DEL_USER_ATTR' => _T("Delete ppolicy attribute", "ppolicy"),
    'PPOLICY_ADD_USER_PPOLICY' => _T("Add ppolicy to user", "ppolicy"),
    'PPOLICY_MOD_USER_PPOLICY' => _T("Update ppolicy for user", "ppolicy"),
    'PPOLICY_DEL_USER_PPOLICY' => _T("Delete ppolicy on user", "ppolicy"),
    'PPOLICY_MOD_ATTR' => _T("Change ppolicy attribute", "ppolicy"),
    'PPOLICY_DEL_ATTR' => _T("Delete ppolicy attribute", "ppolicy"),
    'PPOLICY' => _T("ppolicy", "ppolicy"),
    'MMC-PPOLICY' => _T("ppolicy", "ppolicy"),
);

?>
