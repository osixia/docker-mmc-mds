<?php
$_SESSION['ajax']['filter'] = $_GET['filter'];
?>
