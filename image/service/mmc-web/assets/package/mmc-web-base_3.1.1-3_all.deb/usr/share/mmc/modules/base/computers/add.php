<?php

require_once("modules/base/computers/edit.php");

?>
