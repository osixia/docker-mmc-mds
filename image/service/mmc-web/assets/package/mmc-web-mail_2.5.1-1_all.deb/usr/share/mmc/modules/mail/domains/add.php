<?php

require("modules/mail/domains/edit.php");

?>
